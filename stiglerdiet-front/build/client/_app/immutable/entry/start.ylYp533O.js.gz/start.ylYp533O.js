import{a as t}from"../chunks/entry.DeciWqjl.js";export{t as start};
